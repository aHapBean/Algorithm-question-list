- 2 string utility
  - 2.1 hashing
  - 2.2 kmp
  - 2.3 ex-kmp
  - 2.4 manacher
  - 2.5 aho-corasick automaton AC�Զ���
  - 2.6 suffix array ��׺����
  - 2.7 suffix automaton ��׺�Զ���
  - 2.8 palindromic automaton �����Զ���
  - 2.9 lexicographically-minimal-string-rotation ��С��ʾ��
  - 2.10 palindomic-factorization ���Ĵ��ֽ�
- 3 data structure
  - 3.1 disjoint set union ���鼯
  - 3.2 range minimum/maximum query ST��
  - 3.3 binary index tree ��״����
  - 3.4 two-dimensional binary index tree ��ά��״����
  - 3.5 segment tree �߶���
  - 3.6 heavy-light decomposition �����ʷ�
  - 3.7 Li-chao segment tree ��߶���
  - 3.8 splay
  - 3.9 link cut tree
  - 3.10 irrotational treap ����treap
  - 3.11 KD-tree
  - 3.12 segment tree merging �߶����ϲ�
  - 3.13 persistent treap �ɳ־û�treap
  - 3.14 leftist tree ��ƫ��
  - 3.15 segment tree beats

# 2 string utility

### 2.1 hashing
```
#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int maxn=100007;
struct myHash{
	int hh[maxn],h[maxn];
	int mo,n;
	myHash(int _mo,int _hh){
		mo=_mo;
		hh[0]=1;
		hh[1]=_hh;
	}
	void init(char *s){
		n=strlen(s+1);
		for (int i=2;i<=n;i++) hh[i]=hh[i-1]*1ll*hh[1]%mo;
		for (int i=1;i<=n;i++) h[i]=(h[i-1]*1ll*hh[1]+s[i])%mo;
	}
	int getHash(int l,int r){
		return ((h[r]-h[l-1]*1ll*hh[r-l+1])%mo+mo)%mo;
	}
	int lcp(int x,int y){
		int l=0,r=min(n-x+1,n-y+1);
		while (l<r){
			int mid=l+r+1>>1;
			if (getHash(x,x+mid-1)==getHash(y,y+mid-1)) l=mid;
			else r=mid-1;
		}
		return l;
	}
}myh(998244353,97);
char a[maxn];
int n;
int main(){
}
```

### 2.2 kmp
```
#include<bits/stdc++.h>
using namespace std;

const int maxn=1000007;
int m,b[maxn],fail[maxn];
int main(){
	fail[1]=0;
	int p=0;
	for (int i=2;i<=m;i++){
		while (p && b[p+1]!=b[i]) p=fail[p];
		if (b[p+1]==b[i]) p++;
		fail[i]=p;
	}
	return 0;
}
```

### 2.3 ex-kmp
```
#include<stdio.h>
#include<iostream>
#include<string.h>
using namespace std;

int ext[maxn];
void exkmp(char *s){
	int len=strlen(s+1);
	ext[1]=len;
	int j=2,k;
	for (int i=2;i<=len;i=k){
		if (j<i) j=i;
		while (j<=len && s[j]==s[j-i+1]) j++;
		ext[i]=j-i;
		k=i+1;
		while (k+ext[k-i+1]<j) ext[k]=ext[k-i+1],k++;
	}
}

int main(){
}
```

### 2.4 manacher
```
#include<bits/stdc++.h>
using namespace std;
const int maxn=2000007;
int n;
int a[maxn];

int rad[maxn];
void manacher(){
	int lim=0,res=0,id;
	for (int i=1;i<=n;i++){
		if (i<=lim) rad[i]=min(rad[id*2-i],lim-i);
		else rad[i]=0;
		while (i-rad[i]>1 && i+rad[i]<n && a[i-rad[i]-1]==a[i+rad[i]+1]) rad[i]++;
		if (i+rad[i]>lim){
			lim=i+rad[i];
			id=i;
		}
	}
}

int main(){
	scanf("%d",&n);
	a[1]=-1;
	for (int i=1;i<=n;i++){
		scanf("%d",&a[i*2]);
		a[i*2+1]=-1;
	}
	n=n*2+1;
	manacher();
	return 0;
}
```

### 2.5 aho-corasick automaton AC�Զ���
```
#include<stdio.h>
#include<string.h>
#include<map>
using namespace std;
const int maxn=500007,maxm=1000007;
int t,n,m;
int ans;
char s[maxm];

struct AC{
	int to[maxn][26],cnt[maxn],vis[maxn],fail[maxn];
	int num;
	AC(){
		num=0;
	}
	void init(){
		for (int i=1;i<=num;i++){
			fail[i]=vis[i]=cnt[i]=0;
			memset(to[i],0,sizeof to[i]);
		}
		num=1;
		for (int i=0;i<26;i++) to[0][i]=1;
	}
	void ins(char *s){
		int now=1,len=strlen(s+1);
		for (int i=1;i<=len;i++){
			int x=s[i]-'a';
			if (!to[now][x]) to[now][x]=++num;
			now=to[now][x];
		}
		cnt[now]++;
	}
	int b[maxn];
	void build(){
		b[b[0]=1]=1;
		for (int i=1;i<=b[0];i++){
			int now=b[i];
			for (int x=0;x<26;x++){
				if (!to[now][x]) continue;
				int p=fail[now];
				while (!to[p][x]) p=fail[p];
				fail[to[now][x]]=to[p][x];
				b[++b[0]]=to[now][x];
			}
		}
	}
	void run(char *s){
		int now=1,len=strlen(s+1);
		for (int i=1;i<=len;i++){
			int x=s[i]-'a';
			while (!to[now][x]) now=fail[now];
			now=to[now][x];
			for (int p=now;p && !vis[p];p=fail[p]){
				vis[p]=1;
				ans+=cnt[p];
				cnt[p]=0;
			}
		}
	}
}ac;

int main(){
	int t;
	scanf("%d",&t);
	while (t--){
		ac.init();
		
		ans=0;
		scanf("%d",&n);
		for (int i=1;i<=n;i++){
			scanf("%s",s+1);
			ac.ins(s);
		}
		ac.build();
		scanf("%s",s+1);
		ac.run(s);
		printf("%d\n",ans);
	}
	return 0;
}
```

### 2.6 suffix array ��׺����
```
#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int maxn=100007;
struct SA{
	int n;
	int c[maxn],x[maxn],y[maxn],sa[maxn],rk[maxn],h[maxn];
	int f[maxn][20],lg[maxn];
	void DA(char *s){
		n=strlen(s+1);
		lg[1]=0;
		for (int i=2;i<=n;i++) lg[i]=lg[i/2]+1;
		int m=255;
		for (int i=0;i<=m;i++) c[i]=0;
		for (int i=1;i<=n;i++) c[x[i]=s[i]]++;
		for (int i=2;i<=m;i++) c[i]+=c[i-1];
		for (int i=n;i>=1;i--) sa[c[x[i]]--]=i;
		for (int len=1;len<=n;len<<=1){
			int num=0;
			for (int i=n-len+1;i<=n;i++) y[++num]=i;
			for (int i=1;i<=n;i++) if (sa[i]>len) y[++num]=sa[i]-len;
			for (int i=1;i<=m;i++) c[i]=0;
			for (int i=1;i<=n;i++) c[x[i]]++;
			for (int i=2;i<=m;i++) c[i]+=c[i-1];
			for (int i=n;i>=1;i--) sa[c[x[y[i]]]--]=y[i];
			swap(x,y);
			x[sa[1]]=num=1;
			for (int i=2;i<=n;i++) 
				x[sa[i]]=(y[sa[i]]==y[sa[i-1]] && (sa[i]+len>n?-1:y[sa[i]+len])==
					(sa[i-1]+len>n?-1:y[sa[i-1]+len]))?num:++num;
			if (num==n) break;
			m=num;
		}
		for (int i=1;i<=n;i++) rk[sa[i]]=i;
		int k=0;
		for (int i=1;i<=n;i++){
			if (rk[i]==1) continue;
			if (k) k--;
			int j=sa[rk[i]-1];
			while (i+k<=n && j+k<=n && s[i+k]==s[j+k]) k++;
			h[rk[i]]=k;
		}
		for (int i=1;i<=n;i++) for (int j=0;j<20;j++) f[i][j]=0;
		for (int i=2;i<=n;i++) f[i][0]=h[i];
		for (int j=1;j<20;j++)
			for (int i=2;i+(1<<j)-1<=n;i++) f[i][j]=min(f[i][j-1],f[i+(1<<j-1)][j-1]);
	}
	int lcp(int l,int r){
		if (l==r) return n-l+1;
		if (rk[l]>rk[r]) swap(l,r);
		l=rk[l]+1;
		r=rk[r];
		int k=lg[r-l+1];
		return min(f[l][k],f[r-(1<<k)+1][k]);
	}
}sa;
char a[maxn];
int n;
int main(){
	while (scanf("%s",a+1)!=EOF){
		scanf("%d",&n);
		sa.DA(a);
		ll ans1=0,ans2=0;
		for (int i=1;i<=n;i++){
			int l,r,_l,_r;
			scanf("%d%d",&l,&r);
			l++;r++;
			ans1+=r-l+1;
			if (i==1) ans2+=r-l+3;
			else{
				int temp=min(sa.lcp(l,_l),min(r-l,_r-_l));
				ans2+=(r-l-temp)+2;
				if (temp==0) ans2++;
				while (temp){
					ans2++;
					temp/=10;
				}
			}
			_l=l;
			_r=r;
		}
		printf("%lld %lld\n",ans1,ans2);
	}
}
```

### 2.7 suffix automaton ��׺�Զ���
```
#include<stdio.h>
#include<algorithm>
#include<string.h>
using namespace std;
const int maxn=200007;
int n;
char a[maxn],b[maxn];
int ans;

struct SAM{
	int step[maxn],fa[maxn],to[maxn][26],last,num;
	int cnt[maxn],b[maxn];
	int n;
	SAM(){
		num=0;
	}
	void init(){
		for (int i=0;i<=num;i++){
			step[i]=fa[i]=cnt[i]=b[i]=0;
			memset(to[i],0,sizeof to[i]);
		}
		num=last=1;
		n=0;
	}
	void extend(int x){
		int p=last,np=++num;
		step[np]=step[p]+1;
		while (p && !to[p][x]) to[p][x]=np,p=fa[p];
		if (!p) fa[np]=1;
		else{
			int q=to[p][x];
			if (step[q]==step[p]+1) fa[np]=q;
			else{
				int nq=++num;
				step[nq]=step[p]+1;
				memcpy(to[nq],to[q],sizeof to[q]);
				fa[nq]=fa[q];
				fa[q]=fa[np]=nq;
				while (to[p][x]==q) to[p][x]=nq,p=fa[p];
			}
		}
		last=np;
	}
	void build(char *s){
		n=strlen(s+1);
		for (int i=1;i<=n;i++) extend(s[i]-'a');
	}
	void run(char *s){
		int m=strlen(s+1);
		int len=0,p=1;
		for (int i=1;i<=m;i++){
			int x=s[i]-'a';
			if (to[p][x]){
				p=to[p][x];
				len++;
			}else{
				while (p && !to[p][x]) p=fa[p];
				if (!p){
					len=0;
					p=1;
				}else{
					len=step[p]+1;
					p=to[p][x];
				}
			}
			ans=max(ans,len);
		}
	}
	void work(){
		for (int i=1;i<=num;i++) cnt[step[i]]++;
		for (int i=1;i<=num;i++) cnt[i]+=cnt[i-1];
		for (int i=1;i<=num;i++) b[cnt[step[i]]--]=i;
		for (int i=num;i;i--);
	}
}sam;

int main(){
	sam.init();
	scanf("%s",a+1);
	sam.build(a);
	scanf("%s",b+1);
	ans=0;
	sam.run(b);
	printf("%d\n",ans);
	return 0;
}
```

### 2.8 palindromic automaton �����Զ���
```
#include<stdio.h>
#include<algorithm>
#include<string.h>
using namespace std;

const int maxn=100007;

char a[maxn];
int n;

struct PAM{
	int last,len,num,fa[maxn],step[maxn],to[maxn][26],s[maxn];
	pam(){
		num=0;
	}
	void init(){
		for (int i=0;i<=num;i++){
			memset(to[i],0,sizeof to[i]);
			step[i]=fa[i]=0;
		}
		len=0;
		last=num=2;
		step[1]=-1;
		step[2]=0;
		fa[1]=fa[2]=1;
	}
	int extend(int x){
		int p=last;
		s[++len]=x;
		while (len-step[p]-1<=0 || s[len]!=s[len-step[p]-1]) p=fa[p];
		if (to[p][x]) return to[p][x];
		int np=++num;
		to[p][x]=np;
		step[np]=step[p]+2;
		if (step[np]==1) fa[np]=2;
		else{
			do p=fa[p]; while (len-step[p]-1<=0 || s[len]!=s[len-step[p]-1]);
			fa[np]=to[p][x];
		}
		return np;
	}
	void build(char *a){
		n=strlen(a+1);
		for (int i=1;i<=n;i++) last=extend(a[i]-'a');
	}
}pam;

int main(){
	int t;
	scanf("%d",&t);
	for (int tt=1;tt<=t;tt++){
		pam.init();
		scanf("%s",a+1);
		pam.build(a);
		printf("Case #%d: %d\n",tt,pam.num-2);
	}
	return 0;
}
```

### 2.9 lexicographically-minimal-string-rotation ��С��ʾ��
```
#include<stdio.h>
#include<algorithm>
#include<string.h>
#include<string>
#include<set>
using namespace std;

const int maxn=107;
string s;
set<string> S;
int n,len;
char a[maxn];

int GetMin(){
	int i=1,j=2,k=0;
	while (i<=len && j<=len && k<len){
		int t=a[(i+k-1)%len+1]-a[(j+k-1)%len+1];
		if (!t) k++;
		else{
			if (t>0) i+=k+1;
			else j+=k+1;
			if (i==j) j++;
			k=0;
		}
	}
	return min(i,j);
}

int main(){
	while (scanf("%d",&n)!=EOF){
		S.clear();
		for (int i=1;i<=n;i++){
			scanf("%s",a+1);
			s.clear();
			len=strlen(a+1);
			int x=GetMin();
			for (int j=x;j<=len;j++) s.push_back(a[j]);
			for (int j=1;j<x;j++) s.push_back(a[j]);
			S.insert(s);
		}
		printf("%d\n",S.size());
	}
	return 0;
}
```

### 2.10 palindomic-factorization ���Ĵ��ֽ�
```
#include<stdio.h>
#include<algorithm>
#include<string.h>
using namespace std;

const int maxn=1000007;

char a[maxn],b[maxn],s[maxn];
int n;

struct PAM{
	int last,len,num,fa[maxn],step[maxn],to[maxn][26],s[maxn];
	int diff[maxn],nxt[maxn];
	int f[maxn],g[maxn],F[maxn],G[maxn];
	int n;
	pam(){
		num=0;
	}
	void init(){
		for (int i=0;i<=num;i++){
			memset(to[i],0,sizeof to[i]);
			step[i]=fa[i]=0;
			diff[i]=nxt[i]=0;
		}
		len=0;
		last=num=2;
		step[1]=-1;
		step[2]=0;
		fa[1]=fa[2]=1;
	}
	int extend(int x){
		int p=last;
		s[++len]=x;
		while (len-step[p]-1<=0 || s[len]!=s[len-step[p]-1]) p=fa[p];
		if (to[p][x]) return to[p][x];
		int np=++num;
		to[p][x]=np;
		step[np]=step[p]+2;
		if (step[np]==1) fa[np]=2;
		else{
			do p=fa[p]; while (len-step[p]-1<=0 || s[len]!=s[len-step[p]-1]);
			fa[np]=to[p][x];
		}
		diff[np]=step[np]-step[fa[np]];
		if (diff[np]!=diff[fa[np]]) nxt[np]=fa[np];
		else nxt[np]=nxt[fa[np]];
		return np;
	}
	void build(char *a){
		n=strlen(a+1);
		for (int i=0;i<=n;i++) f[i]=g[i]=998244353;
		f[0]=0;
		for (int i=1;i<=n;i++){
			last=extend(a[i]-'a');
			for (int p=last;nxt[p];p=nxt[p]){
				g[p]=f[i-(step[nxt[p]]+diff[p])];
				G[p]=i-(step[nxt[p]]+diff[p]);
				if (diff[p]==diff[fa[p]]){
					if (g[p]>g[fa[p]]){
						g[p]=g[fa[p]];
						G[p]=G[fa[p]];
					}
				}
				if (i%2==0){
					if (f[i]>g[p]+1){
						f[i]=g[p]+1;
						F[i]=G[p];
					}
				}
			}
			if (i%2==0 && s[i]==s[i-1]){
				if (f[i]>f[i-2]){
					f[i]=f[i-2];
					F[i]=i-2;
				}
			}
		}
		if (f[n]==998244353) printf("-1\n");
		else{
			printf("%d\n",f[n]);
			int p=n;
			while (p){
				if (F[p]==p-2 && s[p]==s[p-1]);
				else printf("%d %d\n",(F[p]+2)/2,p/2);
				p=F[p];
			}
		}
	}
}pam;

int main(){
	pam.init();
	scanf("%s%s",a+1,b+1);
	n=strlen(a+1);
	for (int i=1;i<=n;i++) s[i*2]=b[i],s[i*2-1]=a[i]; 
	pam.build(s);
	return 0;
}
```

# 3 data structure

### 3.1 disjoint set union ���鼯
```
#include<bits/stdc++.h>
using namespace std;
const int maxn=1007;
int dad[maxn];
int getdad(int v){
	return dad[v]?dad[v]=getdad(dad[v]):v;
}
int main(){
}
```

range minimum/maximum query ST��
```
#include<bits/stdc++.h>
using namespace std;
const int maxn=1007;
int n,Q,lg2[maxn];
int mx[maxn][10];
int main(){
	lg2[1]=0;
	for (int i=2;i<maxn;i++) lg2[i]=lg2[i/2]+1;
	int t;
	scanf("%d",&t);
	while (t--){
		scanf("%d",&n);
		for (int i=1;i<=n;i++) scanf("%d",&mx[i][0]);
		for (int i=1;i<10;i++)
			for (int j=1;j<=n;j++){
				mx[j][i]=max(mx[j][i-1],mx[j+(1<<i-1)][i-1]);
			}
		scanf("%d",&Q);
		for (int i=1;i<=Q;i++){
			int l,r;
			scanf("%d%d",&l,&r);
			int j=lg2[r-l+1];
			int ans=max(mx[l][j],mx[r-(1<<j)+1][j]);
			printf("%d\n",ans);
		}
	}
}
```

### 3.2 binary index tree ��״����
```
#include<bits/stdc++.h>
using namespace std;
const int maxn=40007;
int n,ans[maxn],c[maxn];
void modify(int v,int ad){
	for (;v<maxn;v+=v&-v) c[v]+=ad;
}
int getsum(int v){
	int res=0;
	for (;v;v-=v&-v) res+=c[v];
	return res;
}
int main(){
}
```

### 3.3 two-dimensional binary index tree ��ά��״����
```
#include<bits/stdc++.h>
using namespace std;
const int maxn=1007;
int n;
int a[maxn][maxn],c[maxn][maxn];
void modify(int x,int y,int ad){
	x++;y++;
	for (;x<maxn;x+=x&-x)
		for (int i=y;i<maxn;i+=i&-i) c[x][i]+=ad;
}
int getsum(int x,int y){
	x++;y++;
	int res=0;
	for (;x;x-=x&-x)
		for (int i=y;i;i-=i&-i)
			res+=c[x][i];
	return res;
}
int getsum(int x,int y,int xx,int yy){
	return getsum(xx,yy)-getsum(x-1,yy)-getsum(xx,y-1)+getsum(x-1,y-1);
}
int main(){
}
```

### 3.4 segment tree �߶���
```
#include<bits/stdc++.h>
using namespace std;
const int maxn=100007,mo=10007,maxt=maxn*4;
int n,m;
int c[maxt][3],mul[maxt],add[maxt],chg[maxt];
void plant(int l=1,int r=n,int t=1){
	int mid=l+r>>1;
	c[t][0]=c[t][1]=c[t][2]=mul[t]=add[t]=chg[t]=0;
	if (l==r) return;
	plant(l,mid,t*2);
	plant(mid+1,r,t*2+1);
}

void Add(int l,int r,int t,int ad){
	add[t]=(add[t]+ad)%mo;
	c[t][2]=(c[t][2]+3ll*c[t][1]*ad+3ll*c[t][0]*ad*ad+(r-l+1)*1ll*ad*ad*ad)%mo;
	c[t][1]=(c[t][1]+2ll*c[t][0]*ad+(r-l+1)*1ll*ad*ad)%mo;
	c[t][0]=(c[t][0]+(r-l+1)*ad)%mo;
}
void Mul(int l,int r,int t,int ad){
	mul[t]=(mul[t]==0?ad:mul[t]*ad%mo);
	add[t]=add[t]*ad%mo;
	c[t][0]=c[t][0]*ad%mo;
	c[t][1]=c[t][1]*1ll*ad*ad%mo;
	c[t][2]=c[t][2]*1ll*ad*ad*ad%mo;
}
void Chg(int l,int r,int t,int ad){
	mul[t]=0;
	add[t]=0;
	chg[t]=ad;
	c[t][0]=(r-l+1)*1ll*ad%mo;
	c[t][1]=(r-l+1)*1ll*ad*ad%mo;
	c[t][2]=(r-l+1)*1ll*ad*ad*ad%mo;
}
void mkd_chk(int l,int r,int t,int *mychg,void (*myChg)(int,int,int,int)){
	int mid=l+r>>1;
	if (mychg[t]){
		myChg(l,mid,t*2,mychg[t]);
		myChg(mid+1,r,t*2+1,mychg[t]);
		mychg[t]=0;
	}
}
void mkd(int l,int r,int t){
	mkd_chk(l,r,t,chg,Chg);
	mkd_chk(l,r,t,mul,Mul);
	mkd_chk(l,r,t,add,Add);
}

void modify(int v1,int v2,int ad,void (*myChg)(int,int,int,int),int l=1,int r=n,int t=1){
	int mid=l+r>>1;
	if (l>v2 || r<v1) return;
	if (l>=v1 && r<=v2){
		myChg(l,r,t,ad);
		return;
	}
	mkd(l,r,t);
	modify(v1,v2,ad,myChg,l,mid,t*2);
	modify(v1,v2,ad,myChg,mid+1,r,t*2+1);
	for (int i=0;i<3;i++) c[t][i]=(c[t*2][i]+c[t*2+1][i])%mo;
}

int getsum(int v1,int v2,int v,int l=1,int r=n,int t=1){
	int mid=l+r>>1;
	if (l>v2 || r<v1) return 0;
	if (l>=v1 && r<=v2) return c[t][v];
	mkd(l,r,t);
	return (getsum(v1,v2,v,l,mid,t*2)+getsum(v1,v2,v,mid+1,r,t*2+1))%mo;
}

int main(){
	while (1){
		scanf("%d%d",&n,&m);
		if (n==0) break;
		plant();
		for (int i=1;i<=m;i++){
			int typ,x,y,z;
			scanf("%d%d%d%d",&typ,&x,&y,&z);
			if (typ==1) modify(x,y,z,Add);
			else if (typ==2) modify(x,y,z,Mul);
			else if (typ==3) modify(x,y,z,Chg);
			else printf("%d\n",getsum(x,y,z-1));
		}
	}
}
```

### 3.5 heavy-light decomposition �����ʷ�
```
#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int inf=0x7fffffff;
const int maxn=30007,maxm=maxn*2,maxt=maxn*4;
int n,m,i,j,k,num=0,ans,tot=0;
int fi[maxn],ne[maxm],la[maxm],b[maxn];
int top[maxn],de[maxn],son[maxn],si[maxn],fa[maxn],dfn[maxn];
int c[maxt][2];
int a[maxn];
char ch[10];
void add_line(int a,int b){
	tot++;
	ne[tot]=fi[a];
	la[tot]=b;
	fi[a]=tot;
}
void dfs1(int v,int from){
	int k,tmp=0;
	si[v]=1;
	de[v]=de[from]+1;
	for (k=fi[v];k;k=ne[k]){
		if (la[k]!=from){
			dfs1(la[k],v);
			si[v]+=si[la[k]];
			fa[la[k]]=v;
			if (si[la[k]]>tmp) son[v]=la[k],tmp=si[la[k]];
		}
	}
}
void dfs2(int v,int from){
	int k;
	dfn[v]=++num;
	if (son[v]){
		top[son[v]]=top[v];
		dfs2(son[v],v);
		for (k=fi[v];k;k=ne[k]){
			if (la[k]!=from && la[k]!=son[v]) {
				top[la[k]]=la[k];
				dfs2(la[k],v);
			}
		}
	}
}
int getmax(int l,int r,int t,int v1,int v2){
	int mid=(l+r)/2;
	if (v1>r || v2<l) return -inf;
	if (l>=v1 && r<=v2) return c[t][0];
	return max(getmax(l,mid,t*2,v1,v2),getmax(mid+1,r,t*2+1,v1,v2));
}
int getsum(int l,int r,int t,int v1,int v2){
	int mid=(l+r)/2;
	if (v1>r || v2<l) return 0;
	if (l>=v1 && r<=v2) return c[t][1];
	return getsum(l,mid,t*2,v1,v2)+getsum(mid+1,r,t*2+1,v1,v2);
}
void solve(int i,int j,char ch[10]){
	if (ch[0]=='Q' && ch[1]=='M'){
		ans=max(ans,getmax(1,n,1,i,j));
	}else if (ch[0]=='Q'){
		if (ans==-inf) ans=getsum(1,n,1,i,j);
		else ans+=getsum(1,n,1,i,j);
	}
}
void plant(int l,int r,int t){
	int mid=(l+r)/2;
	if (l==r) {
		c[t][0]=c[t][1]=b[l];
		return ;
	}
	plant(l,mid,t*2);
	plant(mid+1,r,t*2+1);
	c[t][0]=max(c[t*2][0],c[t*2+1][0]);
	c[t][1]=c[t*2][1]+c[t*2+1][1];
}
void change(int l,int r,int t,int v,int v1){
	int mid=(l+r)/2;
	if (l==r){
		c[t][0]=c[t][1]=v1;
		return ;
	}
	if (mid>=v) change(l,mid,t*2,v,v1);
	else change(mid+1,r,t*2+1,v,v1);
	c[t][0]=max(c[t*2][0],c[t*2+1][0]);
	c[t][1]=c[t*2][1]+c[t*2+1][1];
}
int main(){
	scanf("%d",&n);
	for (i=1;i<n;i++){
		scanf("%d%d",&j,&k);
		add_line(j,k);
		add_line(k,j);
	}
	for (i=1;i<=n;i++) scanf("%d",&a[i]);
	dfs1(1,0);
	top[1]=1;
	dfs2(1,0);
	for (i=1;i<=n;i++) b[dfn[i]]=a[i];
	plant(1,n,1);
	scanf("%d",&m);
	for (i=1;i<=m;i++){
		ans=-inf;
		scanf("%s%d%d",&ch,&j,&k);
		if (ch[0]=='Q'){
			while (top[j]!=top[k]){
				if (de[top[j]]>de[top[k]]){
					solve(dfn[top[j]],dfn[j],ch);
					j=fa[top[j]];
				}else{
					solve(dfn[top[k]],dfn[k],ch);
					k=fa[top[k]];
				}
			}
			if (dfn[j]<dfn[k]) solve(dfn[j],dfn[k],ch);
			else solve(dfn[k],dfn[j],ch);
			if (ans!=-inf) printf("%d\n",ans);
		}else{
			change(1,n,1,dfn[j],k);
		}
	}
	return 0;
}
```

### 3.6 Li-chao segment tree ��߶���
```
#include<bits/stdc++.h>
#define ll long long
#define db double
using namespace std;
const int n=50000,maxn=50007,maxt=maxn*4;
int Q;
struct lcseg{
	bool bz[maxt];
	db b[maxt],k[maxt];
	void insert(db B,db K,int l=1,int r=n,int t=1){
		if (!bz[t]){
			b[t]=B;
			k[t]=K;
			bz[t]=true;
			return;
		}
		int mid=l+r>>1;
		db l1=l*K+B,r1=r*K+B,l2=l*k[t]+b[t],r2=r*k[t]+b[t];
		if (l1<=l2 && r1<=r2) return;
		if (l1>l2 && r1>r2){
			b[t]=B;
			k[t]=K;
			return;
		}
		db xx=(B-b[t])/(k[t]-K);
		if (l1>l2){
			if (xx>mid){
				insert(b[t],k[t],mid+1,r,t*2+1);
				b[t]=B;
				k[t]=K;
			}else insert(B,K,l,mid,t*2);
		}else{
			if (xx>mid) insert(B,K,mid+1,r,t*2+1);
			else{
				insert(b[t],k[t],l,mid,t*2);
				b[t]=B;
				k[t]=K;
			}
		}
	}
	db query(int x,int l=1,int r=n,int t=1){
		int mid=l+r>>1;
		db res=x*k[t]+b[t];
		if (l<r){
			if (x<=mid) res=max(res,query(x,l,mid,t*2));
			else res=max(res,query(x,mid+1,r,t*2+1));
		}
		return res;
	}
}seg;
int main(){
	scanf("%d",&Q);
	for (int i=1;i<=Q;i++){
		char typ[10];
		db B,K;
		scanf("%s",typ);
		if (typ[0]=='P'){
			scanf("%lf%lf",&B,&K);
			seg.insert(B-K,K);
		}else{
			int x;
			scanf("%d",&x);
			db ans=seg.query(x);
			printf("%lld\n",(ll)(ans*0.01));
		}
	}
    return 0;
}

```

### 3.7 splay
```
#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int maxn=100007;
int n,i,j,k,root,last;
int a[maxn],fa[maxn],minx[maxn],mnid[maxn],si[maxn],d[maxn],son[maxn][2],id[maxn];
bool fz[maxn];
void update(int x){
	if (minx[son[x][0]]<minx[son[x][1]] || minx[son[x][0]]==minx[son[x][1]] && mnid[son[x][0]]<mnid[son[x][1]]) minx[x]=minx[son[x][0]],mnid[x]=mnid[son[x][0]];
	else minx[x]=minx[son[x][1]],mnid[x]=mnid[son[x][1]];
	if (minx[x]>a[x] || minx[x]==a[x] && mnid[x]>x) minx[x]=a[x],mnid[x]=x;
	si[x]=si[son[x][0]]+si[son[x][1]]+1;
}
void zag(int x,int y,int z){
	fa[x]=y;
	if (y){
		son[y][z]=x;
		update(y);
	}else root=x;
}
int pan(int x){
	return son[fa[x]][1]==x;
}
void zig(int x){
	int y=fa[fa[x]],z=pan(x),zz=pan(fa[x]);
	zag(son[x][z^1],fa[x],z);
	zag(fa[x],x,z^1);
	zag(x,y,zz);
}
void markdown(int x){
	if (x && fz[x]){
		int k=son[x][0];
		zag(son[x][1],x,0);
		zag(k,x,1);
		fz[x]=false;
		fz[son[x][0]]^=true;
		fz[son[x][1]]^=true;
	}
}
void markclear(int x,int y){
	for (d[0]=0;x!=y;x=fa[x]) d[++d[0]]=x;
	while (d[0]) markdown(d[d[0]--]);
}
void splay(int x,int y){
	if (x==y) return;
	markclear(x,y);
	while (fa[x]!=y){
		if (fa[fa[x]]!=y) 
			if (pan(fa[x])==pan(x)) zig(fa[x]);
			else zig(x);
		zig(x);
	}
}
int main(){
	return 0;
}
```

### 3.8 link cut tree
```
#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int inf=0x7fffffff;
const int maxN=1000007;
int va[maxN],st[maxN],rev[maxN],fa[maxN],son[maxN][2],mn[maxN];
bool isrt(int x){
	return son[fa[x]][0]!=x && son[fa[x]][1]!=x;
}
bool pan(int x){
	return son[fa[x]][1]==x;
}
void update(int x){
	mn[x]=min(mn[son[x][0]],min(mn[son[x][1]],va[x]));
}
void mkd(int x){
	if (rev[x]){
		rev[x]^=1;
		rev[son[x][0]]^=1;
		rev[son[x][1]]^=1;
		swap(son[x][0],son[x][1]);
	}
}
void zag(int x,int y,int z,bool flag=true){
	fa[x]=y;
	if (flag){
		son[y][z]=x;
		update(y);
	}
}
void zig(int x){
	int y=fa[fa[x]],z=pan(x),zz=pan(fa[x]);
	bool flag=!isrt(fa[x]);
	zag(son[x][z^1],fa[x],z);
	zag(fa[x],x,z^1);
	zag(x,y,zz,flag);
}
void splay(int x){
	int p=x;
	st[st[0]=1]=p;
	for(int y=fa[p];!isrt(p);p=y,y=fa[p]) st[++st[0]]=y;
	while (st[0]) mkd(st[st[0]--]);
	for(int y=fa[x],z=fa[y];!isrt(x);z=fa[y=fa[x]]){
		if (!isrt(y)) 
			if (pan(y)==pan(x)) zig(y);
			else zig(x);
		zig(x);
	}
	update(x);
}
void access(int x){
	for(int t=0;x;x=fa[x]){
		splay(x);
		son[x][1]=t;
		update(x);
		t=x;
	}
}
void makeroot(int x){
	access(x);
	splay(x);
	rev[x]^=1;
}
void link(int x,int y){
	makeroot(x);
	fa[x]=y;
}
void cut(int x,int y){
	makeroot(x);
	access(y);
	splay(y);
	son[y][0]=fa[x]=0;
	update(y);
}
int query(int x,int y){
	makeroot(x);
	access(y);
	splay(y);
	while (son[y][0]) y=son[y][0];
	if (y!=x) return 0;
	splay(x);
	return mn[x];
}
int main(){
	return 0;
}
```

### 3.9 irrotational treap ����treap
```
#include<bits/stdc++.h>
using namespace std;
const int maxn=1000070,inf=0x7fffffff;
int rrand(){
	return rand()*rand()+rand();
}
struct treap{
	int c[maxn],ls[maxn],rs[maxn],rk[maxn],siz[maxn],num;
	void init(){
		num=0;
		newnode(inf);
		siz[1]=0;
	}
	void update(int t){
		siz[t]=siz[ls[t]]+siz[rs[t]]+1;
	}
	int newnode(int x){
		num++;
		c[num]=x;
		siz[num]=1;
		ls[num]=rs[num]=0;
		rk[num]=rrand();
		return num;
	}
	void split(int t,int &a,int &b,int ad){
		if (t==0) return void(a=b=0);
		if (c[t]<=ad){
			a=t;
			split(rs[t],rs[a],b,ad);
		}else{
			b=t;
			split(ls[t],a,ls[b],ad);
		}
		update(t);
	}
	void merge(int &t,int a,int b){
		if (a==0 || b==0) return void(t=a+b);
		if (rk[a]<rk[b]){
			t=a;
			merge(rs[t],rs[a],b);
		}else{
			t=b;
			merge(ls[t],a,ls[b]);
		}
		update(t);
	}
	void insert(int &t,int ad){
		int x=0,y=0,temp=newnode(ad);
		split(t,x,y,ad);
		merge(x,x,temp);
		merge(t,x,y);
	}
	void erase(int &t,int ad){
		int x=0,y=0,z=0;
		split(t,x,y,ad);
		split(x,x,z,ad-1);
		merge(z,ls[z],rs[z]);
		merge(x,x,z);
		merge(t,x,y);
	}
	int getkth(int t,int k){
		while (siz[ls[t]]+1!=k)
			if (siz[ls[t]]>=k) t=ls[t];
			else k-=siz[ls[t]]+1,t=rs[t];
		return c[t];
	}
	int getrank(int &t,int ad){
		int x=0,y=0;
		split(t,x,y,ad-1);
		int res=siz[x]+1;
		merge(t,x,y);
		return res;
	}
	int getpre(int &t,int ad){
		int x=0,y=0;
		split(t,x,y,ad-1);
		int res=getkth(x,siz[x]);
		merge(t,x,y);
		return res;
	}
	int getscc(int &t,int ad){
		int x=0,y=0;
		split(t,x,y,ad);
		int res=getkth(y,1);
		merge(t,x,y);
		return res;
	}
}tr;
int root=0;
int n;
int main(){
	tr.init();
	root=1;
	scanf("%d",&n);
	for (int i=1;i<=n;i++){
		int typ,x;
		scanf("%d%d",&typ,&x);
		if (typ==1){
			tr.insert(root,x);
		}else if (typ==2){
			tr.erase(root,x);
		}else if (typ==3){
			printf("%d\n",tr.getrank(root,x));
		}else if (typ==4){
			printf("%d\n",tr.getkth(root,x));
		}else if (typ==5){
			printf("%d\n",tr.getpre(root,x));
		}else{
			printf("%d\n",tr.getscc(root,x));
		}
	}
}
```

### 3.10 KD-tree
```
struct P{
	int a[3];
	int& operator [](const int &typ){
		return a[typ];
	}
	const int& operator [](const int &typ)const{
		return a[typ];
	}
};
struct cmp{
	int typ;
	cmp(int x){
		typ=x;
	}
	bool operator ()(const P &a,const P &b)const{
		return a[typ]<b[typ];
	}
};
struct kdtree{
	int root;
	P x[maxn],lx[maxn],rx[maxn];
	int ls[maxn],rs[maxn],cnt[maxn];
	int plant(int l=1,int r=n,int t=0){
		int mid=l+r>>1;
		nth_element(x+l,x+mid,x+r+1,cmp(t));
		if (l<=mid-1) ls[mid]=plant(l,mid-1,(t+1)%3);
		if (mid+1<=r) rs[mid]=plant(mid+1,r,(t+1)%3);
		cnt[mid]=1+cnt[ls[mid]]+cnt[rs[mid]];
		fo(i,0,2){
			lx[mid][i]=x[mid][i];
			rx[mid][i]=x[mid][i];
			if (ls[mid]){
				lx[mid][i]=min(lx[mid][i],lx[ls[mid]][i]);
				rx[mid][i]=max(rx[mid][i],rx[ls[mid]][i]);
			}
			if (rs[mid]){
				lx[mid][i]=min(lx[mid][i],lx[rs[mid]][i]);
				rx[mid][i]=max(rx[mid][i],rx[rs[mid]][i]);
			}
		}
		return mid;
	}
	int query(int l0,int r0,int l1,int r1,int l2,int r2,int t){
		#define INSIDE(x,y,z) ((x)>=(y) && (x)<=(z))
		#define INSI(x,y,xx,yy) ((x)>=(xx) && (y)<=(yy))
		#define OUTSI(x,y,xx,yy) ((x)>(yy) || (y)<(xx))
		if (!t) return 0;		
		if (OUTSI(lx[t][0],rx[t][0],l0,r0) || OUTSI(lx[t][1],rx[t][1],l1,r1) || OUTSI(lx[t][2],rx[t][2],l2,r2)) {
			return 0;
		}
		if (INSI(lx[t][0],rx[t][0],l0,r0) && INSI(lx[t][1],rx[t][1],l1,r1) && INSI(lx[t][2],rx[t][2],l2,r2)) return cnt[t];
		return (INSIDE(x[t][0],l0,r0) && INSIDE(x[t][1],l1,r1) && INSIDE(x[t][2],l2,r2))
			+query(l0,r0,l1,r1,l2,r2,ls[t])+query(l0,r0,l1,r1,l2,r2,rs[t]);
		#undef INSIDE
		#undef INSI
		#undef OUTSI
	}
int main(){
	fo(i,1,n) fo(j,0,2) kdt.x[i][j]=...;
	kdt.root=kdt.plant();
}
```

### 3.11 segment tree merging �߶����ϲ�
```
#include<bits/stdc++.h>
using namespace std;
const int maxn=200007;
int n;

const int maxt=maxn*30;
int cnt=0,c[maxt],ls[maxt],rs[maxt];
int newnode(){
	cnt++;
	c[cnt]=ls[cnt]=rs[cnt]=0;
	return cnt;
}
void modify(int t,int v,int l=1,int r=n){
	int mid=l+r>>1;
	if (l==r){
		c[t]++;
		return;
	}
	if (v<=mid){
		if (!ls[t]) ls[t]=newnode();
		modify(ls[t],v,l,mid);
	}else{
		if (!rs[t]) rs[t]=newnode();
		modify(rs[t],v,mid+1,r);
	}
	c[t]=c[ls[t]]+c[rs[t]];
}
int query(int t,int v,int l=1,int r=n){
	int mid=l+r>>1;
	if (c[t]<v) return -1;
	if (l==r) return l;
	if (c[ls[t]]>=v) return query(ls[t],v,l,mid);
	return query(rs[t],v-c[ls[t]],mid+1,r);
}
int merge(int u,int v){
    if (!u) return v;
    if (!v) return u;
    int t = newnode();
    c[t] = c[u] + c[v];
    ls[t] = merge(ls[u],ls[v]);
    rs[t] = merge(rs[u],rs[v]);
    return t;
}

int main(){
	return 0;
}
```

### 3.12 persistent treap �ɳ־û�treap
```
#include<bits/stdc++.h>
using namespace std;
const int maxn=15000070,inf=0x7fffffff;
int rrand(){
	return rand()*rand()+rand();
}
struct treap{
	int c[maxn],ls[maxn],rs[maxn],rk[maxn],siz[maxn],num;
	void init(){
		num=0;
		newnode(inf);
		siz[1]=1;
	}
	void update(int t){
		siz[t]=siz[ls[t]]+siz[rs[t]]+1;
	}
	int newnode(int x){
		num++;
		c[num]=x;
		siz[num]=1;
		ls[num]=rs[num]=0;
		rk[num]=rrand();
		return num;
	}
	int copy(int t){
		num++;
		ls[num]=ls[t];
		rs[num]=rs[t];
		c[num]=c[t];
		siz[num]=siz[t];
		rk[num]=rk[t];
		return num;
	}
	void split(int t,int &a,int &b,int ad){
		if (t==0) return void(a=b=0);
		if (c[t]<=ad){
			a=copy(t);
			split(rs[t],rs[a],b,ad);
			update(a);
		}else{
			b=copy(t);
			split(ls[t],a,ls[b],ad);
			update(b);
		}
	}
	void merge(int &t,int a,int b){
		if (a==0 || b==0) return void(t=a+b);
		if (rk[a]<rk[b]){
			t=a;
			merge(rs[t],rs[a],b);
		}else{
			t=b;
			merge(ls[t],a,ls[b]);
		}
		update(t);
	}
	void insert(int &t,int ad){
		int x=0,y=0,temp=newnode(ad);
		split(t,x,y,ad);
		merge(x,x,temp);
		merge(t,x,y);
	}
	void erase(int &t,int ad){
		int x=0,y=0,z=0;
		split(t,x,y,ad);
		split(x,x,z,ad-1);
		merge(z,ls[z],rs[z]);
		merge(x,x,z);
		merge(t,x,y);
	}
	int getkth(int t,int k){
		while (siz[ls[t]]+1!=k)
			if (siz[ls[t]]>=k) t=ls[t];
			else k-=siz[ls[t]]+1,t=rs[t];
		return c[t];
	}
	int getrank(int &t,int ad){
		int x=0,y=0;
		split(t,x,y,ad-1);
		int res=siz[x]+1;
		merge(t,x,y);
		return res;
	}
	int getpre(int &t,int ad){
		int x=0,y=0;
		split(t,x,y,ad-1);
		int res=getkth(x,siz[x]);
		merge(t,x,y);
		return res;
	}
	int getscc(int &t,int ad){
		int x=0,y=0;
		split(t,x,y,ad);
		int res=getkth(y,1);
		merge(t,x,y);
		return res;
	}
}tr;
int rt[maxn];
int n;
int main(){
	rt[0]=tr.newnode(inf);
	tr.insert(rt[0],-inf);
	scanf("%d",&n);
	for (int i=1;i<=n;i++){
		int v,typ,x;
		scanf("%d%d%d",&v,&typ,&x);
		rt[i]=tr.copy(rt[v]);
		if (typ==1){
			tr.insert(rt[i],x);
		}else if (typ==2){
			tr.erase(rt[i],x);
		}else if (typ==3){
			printf("%d\n",tr.getrank(rt[i],x)-1);
		}else if (typ==4){
			printf("%d\n",tr.getkth(rt[i],x+1));
		}else if (typ==5){
			printf("%d\n",tr.getpre(rt[i],x));
		}else{
			printf("%d\n",tr.getscc(rt[i],x));
		}
	}
}
```

### 3.13 leftist tree ��ƫ��
```
#include<bits/stdc++.h>
#define ll long long
using namespace std;

const int maxn=100007;
struct ltree{
	int num,c[maxn],ls[maxn],rs[maxn],fa[maxn],dis[maxn];
	int newnode(int x){
		num++;
		ls[num]=rs[num]=0;
		fa[num]=0;
		dis[num]=-1;
		c[num]=x;
		return num;
	}
	int getfa(int v){
		return fa[v]?getfa(fa[v]):v;
	}
	int merge(int x,int y){
		if (x==0 || y==0) return x+y;
		if (c[x]<c[y]) swap(x,y);
		rs[x]=merge(rs[x],y);
		fa[rs[x]]=x;
		if (dis[rs[x]]>dis[ls[x]]) swap(ls[x],rs[x]);
		dis[x]=dis[rs[x]]+1;
		return x;
	}
	int del(int x){
		fa[ls[x]]=fa[rs[x]]=0;
		int res=merge(ls[x],rs[x]);
		ls[x]=rs[x]=0;
		dis[x]=0;
		return res;
	}
	int solve(int x,int y){
		int l=del(x),r=del(y);
		c[x]>>=1;
		c[y]>>=1;
		l=merge(l,x);
		r=merge(r,y);
		l=merge(l,r);
		return c[l];
	}
}lt;
int n,a[maxn];
int main(){
	while (scanf("%d",&n)!=EOF){
		lt.num=0;
		for (int i=1;i<=n;i++){
			int x;
			scanf("%d",&x);
			lt.newnode(x);
		}
		int Q;
		scanf("%d",&Q);
		for (int i=1;i<=Q;i++){
			int x,y;
			scanf("%d%d",&x,&y);
			x=lt.getfa(x);
			y=lt.getfa(y);
			if (x!=y) printf("%d\n",lt.solve(x,y));
			else printf("-1\n");
		}
	}
}
```

### 3.14 segment tree beats
```
#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int maxn=1e6+7,maxt=maxn*4;
int n,m,a[maxn];

ll sum[maxt],mx[maxt],se[maxt],cnt[maxt];
void update(int t){
	sum[t]=sum[t*2]+sum[t*2+1];
	mx[t]=max(mx[t*2],mx[t*2+1]);
	if (mx[t*2]==mx[t*2+1]){
		se[t]=max(se[t*2],se[t*2+1]);
		cnt[t]=cnt[t*2]+cnt[t*2+1];
	}else{
		se[t]=max(se[t*2],max(se[t*2+1],min(mx[t*2],mx[t*2+1])));
		cnt[t]=(mx[t*2]>mx[t*2+1]?cnt[t*2]:cnt[t*2+1]);
	}
}
void mark(int t,int x){
	if (x>=mx[t]) return;
	sum[t]-=cnt[t]*(mx[t]-x);
void mkd(int t){
	mark(t*2,mx[t]);
	mark(t*2+1,mx[t]);
}
void plant(int l=1,int r=n,int t=1){
	int mid=l+r>>1;
	if (l==r){
		sum[t]=mx[t]=a[l];
		se[t]=-1;
		cnt[t]=1;
		return ;
	}
	plant(l,mid,t*2);
	plant(mid+1,r,t*2+1);
	mx[t]=x;
}
	update(t);
}
void modify(int v1,int v2,int x,int l=1,int r=n,int t=1){
	int mid=l+r>>1;
	if (x>=mx[t]) return;
	if (l>v2 || r<v1) return;
	if (l>=v1 && r<=v2 && se[t]<x){
		mark(t,x);
		return;
	}
	mkd(t);
	modify(v1,v2,x,l,mid,t*2);
	modify(v1,v2,x,mid+1,r,t*2+1);
	update(t);
}
ll getmax(int v1,int v2,int l=1,int r=n,int t=1){
	int mid=l+r>>1;
	if (l>v2 || r<v1) return 0;
	if (l>=v1 && r<=v2) return mx[t];
	mkd(t);
	return max(getmax(v1,v2,l,mid,t*2),getmax(v1,v2,mid+1,r,t*2+1));
}
ll getsum(int v1,int v2,int l=1,int r=n,int t=1){
	int mid=l+r>>1;
	if (l>v2 || r<v1) return 0;
	if (l>=v1 && r<=v2) return sum[t];
	mkd(t);
	return getsum(v1,v2,l,mid,t*2)+getsum(v1,v2,mid+1,r,t*2+1);
}

int main(){
	int t;
	scanf("%d",&t);
	while (t--){
		scanf("%d%d",&n,&m);
		for (int i=1;i<=n;i++) scanf("%d",&a[i]);
		plant();
		for (int i=1;i<=m;i++){
			int typ,l,r,x;
			scanf("%d%d%d",&typ,&l,&r);
			if (typ==0){
				scanf("%d",&x);
				modify(l,r,x);
			}else if (typ==1) printf("%lld\n",getmax(l,r));	
			else printf("%lld\n",getsum(l,r));
		}
	}
}
```